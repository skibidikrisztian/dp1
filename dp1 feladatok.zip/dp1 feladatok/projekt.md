# Projektek
>Meg kell tanulni hogyan kell megtanulni

`kód` Print("Hello World!)

[oldalam](https://www.markdownguide.org/cheat-sheet/)