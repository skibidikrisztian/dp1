# Önéletrajz
**Krisztiánnak** *hívnak*
1.iskola
2.iskola
3.iskola3 

-iskola
-gym
-séta
