# Jövőbeli céljaim
1.tanulás
2.munka
3.utazás

| 2026| Érettségi | tanulás |
| ----------- | ----------- | ----------- |

![kepi](image.png)
