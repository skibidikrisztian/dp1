# Kedvenc Könyveim
| A kis herceg | Antoine de Saint-Exupéry | 1943 |
| ----------- | ----------- | ----------- |
| Harry Potter 1 | J.K Rowling | 1997 |
| Harry Potter 2 | J.K Rowling | 1998 |
*Ezek a kedvenc könyveim*

